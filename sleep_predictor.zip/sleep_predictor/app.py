from flask import Flask, render_template, request, jsonify
import pickle
import numpy as np
import pandas as pd
from datetime import datetime
import json
import os
from joblib import load

app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False

# Load the trained model and scaler
model = load('models/sleep_quality_model.pkl')
scaler = load('models/scaler.pkl')
feature_names = load('models/feature_names.pkl')

# File to store prediction history
HISTORY_FILE = 'prediction_history.json'

def load_history():
    """Load prediction history from file"""
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, 'r') as f:
            return json.load(f)
    return []

def save_history(history):
    """Save prediction history to file"""
    with open(HISTORY_FILE, 'w') as f:
        json.dump(history, f, indent=2)

def get_sleep_recommendations(sleep_quality, features):
    """Generate personalized recommendations based on prediction"""
    recommendations = []
    
    sleep_duration = features.get('sleep_duration', 0)
    screen_time = features.get('screen_time_before_bed', 0)
    stress_level = features.get('stress_level', 0)
    exercise_duration = features.get('exercise_duration', 0)
    caffeine_intake = features.get('caffeine_intake', 0)
    
    if sleep_quality == 'Poor':
        if sleep_duration < 6:
            recommendations.append("🎯 Aim for 7-9 hours of sleep daily")
        if screen_time > 60:
            recommendations.append("📱 Reduce screen time to 30 minutes before bed")
        if stress_level > 6:
            recommendations.append("😌 Practice meditation or deep breathing exercises")
        if exercise_duration < 30:
            recommendations.append("🏃 Increase daily exercise to at least 30 minutes")
        if caffeine_intake >= 2:
            recommendations.append("☕ Reduce caffeine intake, especially after 2 PM")
    
    elif sleep_quality == 'Average':
        if sleep_duration < 7:
            recommendations.append("✓ Try to sleep an extra 30 minutes")
        if screen_time > 30:
            recommendations.append("📱 Gradually reduce screen time before bed")
        if stress_level > 5:
            recommendations.append("😌 Consider stress management techniques")
        if exercise_duration < 45:
            recommendations.append("🏃 Increase exercise frequency")
    
    else:  # Good
        recommendations.append("✅ Great! Maintain your current sleep routine")
        recommendations.append("📊 Keep tracking to maintain consistency")
    
    return recommendations if recommendations else ["✅ You're doing great! Keep it up!"]

@app.route('/')
def index():
    """Render main page"""
    return render_template('index.html')

@app.route('/api/predict', methods=['POST'])
def predict():
    """Predict sleep quality based on user input"""
    try:
        data = request.json
        
        # Extract features in the correct order
        features_dict = {
            'sleep_duration': float(data.get('sleep_duration', 0)),
            'bedtime_hour': float(data.get('bedtime_hour', 22)),
            'wakeup_hour': float(data.get('wakeup_hour', 6)),
            'caffeine_intake': float(data.get('caffeine_intake', 0)),
            'exercise_duration': float(data.get('exercise_duration', 0)),
            'screen_time_before_bed': float(data.get('screen_time_before_bed', 0)),
            'stress_level': float(data.get('stress_level', 5)),
            'mood_before_sleep': float(data.get('mood_before_sleep', 2)),
            'sleep_interruptions': float(data.get('sleep_interruptions', 0)),
        }
        
        # Create feature array in correct order
        features_array = np.array([[
            features_dict['sleep_duration'],
            features_dict['bedtime_hour'],
            features_dict['wakeup_hour'],
            features_dict['caffeine_intake'],
            features_dict['exercise_duration'],
            features_dict['screen_time_before_bed'],
            features_dict['stress_level'],
            features_dict['mood_before_sleep'],
            features_dict['sleep_interruptions']
        ]])
        
        # Scale features
        features_scaled = scaler.transform(features_array)
        
        # Make prediction
        prediction = model.predict(features_scaled)[0]
        probability = model.predict_proba(features_scaled)[0]
        
        # Map prediction to quality
        quality_map = {0: 'Poor', 1: 'Average', 2: 'Good'}
        sleep_quality = quality_map[prediction]
        
        # Get recommendations
        recommendations = get_sleep_recommendations(sleep_quality, features_dict)
        
        # Store in history
        history = load_history()
        history_entry = {
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'inputs': features_dict,
            'prediction': sleep_quality,
            'confidence': float(probability[prediction]) * 100
        }
        history.append(history_entry)
        save_history(history)
        
        return jsonify({
            'status': 'success',
            'sleep_quality': sleep_quality,
            'confidence': round(float(probability[prediction]) * 100, 2),
            'probabilities': {
                'poor': round(float(probability[0]) * 100, 2),
                'average': round(float(probability[1]) * 100, 2),
                'good': round(float(probability[2]) * 100, 2)
            },
            'recommendations': recommendations
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 400

@app.route('/api/history', methods=['GET'])
def get_history():
    """Get prediction history"""
    history = load_history()
    return jsonify({
        'status': 'success',
        'history': history[-20:],  # Last 20 predictions
        'total': len(history)
    })

@app.route('/api/clear-history', methods=['POST'])
def clear_history():
    """Clear prediction history"""
    save_history([])
    return jsonify({'status': 'success', 'message': 'History cleared'})

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get statistics from history"""
    history = load_history()
    
    if not history:
        return jsonify({
            'status': 'success',
            'total_predictions': 0,
            'quality_distribution': {'Poor': 0, 'Average': 0, 'Good': 0},
            'avg_stress': 0,
            'avg_sleep_duration': 0
        })
    
    quality_counts = {'Poor': 0, 'Average': 0, 'Good': 0}
    total_stress = 0
    total_sleep = 0
    
    for entry in history:
        quality_counts[entry['prediction']] += 1
        total_stress += entry['inputs'].get('stress_level', 0)
        total_sleep += entry['inputs'].get('sleep_duration', 0)
    
    return jsonify({
        'status': 'success',
        'total_predictions': len(history),
        'quality_distribution': quality_counts,
        'avg_stress': round(total_stress / len(history), 2),
        'avg_sleep_duration': round(total_sleep / len(history), 2)
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
