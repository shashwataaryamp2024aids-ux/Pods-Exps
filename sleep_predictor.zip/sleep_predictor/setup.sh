#!/bin/bash

# Sleep Quality Predictor - Setup Script for macOS/Linux

echo ""
echo "========================================"
echo "Sleep Quality Predictor Setup"
echo "========================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.8+ from https://www.python.org/"
    exit 1
fi

echo "[1/4] Creating virtual environment..."
python3 -m venv venv

echo "[2/4] Activating virtual environment..."
source venv/bin/activate

echo "[3/4] Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    exit 1
fi

echo "[4/4] Training ML model..."
python3 train_model.py

if [ $? -ne 0 ]; then
    echo "ERROR: Failed to train model"
    exit 1
fi

echo ""
echo "========================================"
echo "✅ Setup Complete!"
echo "========================================"
echo ""
echo "To start the application:"
echo "  1. Run: ./run.sh"
echo "  2. Open browser: http://localhost:5000"
echo ""
