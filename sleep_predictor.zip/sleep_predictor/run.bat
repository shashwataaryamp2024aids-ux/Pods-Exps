@echo off
REM Sleep Quality Predictor - Run Script

echo.
echo ========================================
echo Sleep Quality Predictor
echo ========================================
echo.

call venv\Scripts\activate.bat

echo Starting application...
echo.
echo 🌙 Open your browser and visit: http://localhost:5000
echo 🛑 To stop the server, press Ctrl+C
echo.

python app.py
pause
