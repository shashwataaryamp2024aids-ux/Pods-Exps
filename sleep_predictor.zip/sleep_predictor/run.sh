#!/bin/bash

# Sleep Quality Predictor - Run Script

echo ""
echo "========================================"
echo "Sleep Quality Predictor"
echo "========================================"
echo ""

source venv/bin/activate

echo "Starting application..."
echo ""
echo "🌙 Open your browser and visit: http://localhost:5000"
echo "🛑 To stop the server, press Ctrl+C"
echo ""

python3 app.py
