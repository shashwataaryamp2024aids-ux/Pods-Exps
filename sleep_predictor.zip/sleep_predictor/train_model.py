import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns
from joblib import dump
import os

# Create models directory if it doesn't exist
os.makedirs('models', exist_ok=True)

print("=" * 60)
print("SLEEP QUALITY PREDICTOR - MODEL TRAINING")
print("=" * 60)

# Generate synthetic dataset with realistic patterns
np.random.seed(42)
n_samples = 500

# Sleep duration (hours)
sleep_duration = np.random.normal(7, 1.5, n_samples)
sleep_duration = np.clip(sleep_duration, 3, 12)

# Bedtime (24-hour format)
bedtime_hour = np.random.normal(22.5, 1.5, n_samples)
bedtime_hour = np.clip(bedtime_hour, 20, 2)

# Wake-up time
wakeup_hour = bedtime_hour + sleep_duration
wakeup_hour = np.where(wakeup_hour > 24, wakeup_hour - 24, wakeup_hour)

# Caffeine intake (0-3 scale: none, low, moderate, high)
caffeine_intake = np.random.randint(0, 4, n_samples)

# Exercise duration (minutes)
exercise_duration = np.random.normal(40, 25, n_samples)
exercise_duration = np.clip(exercise_duration, 0, 180)

# Screen time before bed (minutes)
screen_time_before_bed = np.random.normal(60, 40, n_samples)
screen_time_before_bed = np.clip(screen_time_before_bed, 0, 240)

# Stress level (0-10 scale)
stress_level = np.random.normal(5, 2.5, n_samples)
stress_level = np.clip(stress_level, 0, 10)

# Mood before sleep (0-3: sad, neutral, happy, anxious)
mood_before_sleep = np.random.randint(0, 4, n_samples)

# Sleep interruptions (0-1: no, yes)
sleep_interruptions = np.random.randint(0, 2, n_samples)

# Create features dataframe
X = pd.DataFrame({
    'sleep_duration': sleep_duration,
    'bedtime_hour': bedtime_hour,
    'wakeup_hour': wakeup_hour,
    'caffeine_intake': caffeine_intake,
    'exercise_duration': exercise_duration,
    'screen_time_before_bed': screen_time_before_bed,
    'stress_level': stress_level,
    'mood_before_sleep': mood_before_sleep,
    'sleep_interruptions': sleep_interruptions
})

# Generate labels based on features (realistic rules)
y = []
for idx in range(n_samples):
    score = 0
    
    # Sleep duration contribution
    if 7 <= sleep_duration[idx] <= 9:
        score += 3
    elif 6 <= sleep_duration[idx] < 7 or 9 < sleep_duration[idx] <= 10:
        score += 1
    
    # Exercise contribution
    if exercise_duration[idx] >= 30:
        score += 2
    elif exercise_duration[idx] >= 15:
        score += 1
    
    # Screen time contribution
    if screen_time_before_bed[idx] < 30:
        score += 3
    elif screen_time_before_bed[idx] < 60:
        score += 1
    
    # Stress level contribution
    if stress_level[idx] <= 3:
        score += 3
    elif stress_level[idx] <= 6:
        score += 1
    
    # Caffeine contribution
    if caffeine_intake[idx] == 0:
        score += 2
    elif caffeine_intake[idx] == 1:
        score += 1
    
    # Mood contribution
    if mood_before_sleep[idx] in [1, 2]:  # Neutral or Happy
        score += 2
    
    # Sleep interruptions
    if sleep_interruptions[idx] == 0:
        score += 2
    
    # Bedtime regularity
    if 21 <= bedtime_hour[idx] <= 23:
        score += 1
    
    # Classify: 0=Poor, 1=Average, 2=Good
    if score >= 14:
        y.append(2)  # Good
    elif score >= 8:
        y.append(1)  # Average
    else:
        y.append(0)  # Poor

y = np.array(y)

print(f"\n📊 Dataset Generated:")
print(f"   • Total samples: {len(X)}")
print(f"   • Features: {X.columns.tolist()}")
print(f"   • Class distribution:")
print(f"     - Poor: {np.sum(y == 0)} ({np.sum(y == 0)/len(y)*100:.1f}%)")
print(f"     - Average: {np.sum(y == 1)} ({np.sum(y == 1)/len(y)*100:.1f}%)")
print(f"     - Good: {np.sum(y == 2)} ({np.sum(y == 2)/len(y)*100:.1f}%)")

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"\n✂️  Train-Test Split:")
print(f"   • Training set: {len(X_train)} samples")
print(f"   • Testing set: {len(X_test)} samples")

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

print(f"\n📈 Feature Scaling: StandardScaler applied")

# Train multiple models and compare
print(f"\n🤖 Training Models:")
print("-" * 60)

models = {
    'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
    'Decision Tree': DecisionTreeClassifier(max_depth=10, random_state=42),
    'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42),
    'SVM': SVC(kernel='rbf', probability=True, random_state=42)
}

results = {}
best_model = None
best_accuracy = 0
best_name = None

for name, model in models.items():
    model.fit(X_train_scaled, y_train)
    
    # Predictions
    y_pred = model.predict(X_test_scaled)
    accuracy = accuracy_score(y_test, y_pred)
    
    # Cross-validation
    cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=5)
    
    results[name] = {
        'model': model,
        'accuracy': accuracy,
        'cv_mean': cv_scores.mean(),
        'cv_std': cv_scores.std()
    }
    
    print(f"\n{name}:")
    print(f"   • Test Accuracy: {accuracy:.4f}")
    print(f"   • Cross-Val (5-fold): {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")
    
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_model = model
        best_name = name

print(f"\n{'='*60}")
print(f"🏆 BEST MODEL: {best_name} (Accuracy: {best_accuracy:.4f})")
print(f"{'='*60}")

# Detailed evaluation of best model
y_pred = best_model.predict(X_test_scaled)

print(f"\n📋 Detailed Classification Report:")
print("-" * 60)
print(classification_report(
    y_test, y_pred,
    target_names=['Poor', 'Average', 'Good']
))

print(f"\nConfusion Matrix:")
cm = confusion_matrix(y_test, y_pred)
print(cm)

# Feature importance (if available)
if hasattr(best_model, 'feature_importances_'):
    print(f"\n🔍 Feature Importance (Top 5):")
    feature_importance = pd.DataFrame({
        'feature': X.columns,
        'importance': best_model.feature_importances_
    }).sort_values('importance', ascending=False)
    
    for idx, row in feature_importance.head(5).iterrows():
        print(f"   {row['feature']}: {row['importance']:.4f}")

# Save model, scaler, and feature names
print(f"\n💾 Saving Model Artifacts:")
dump(best_model, 'models/sleep_quality_model.pkl')
print(f"   ✓ Model saved to models/sleep_quality_model.pkl")

dump(scaler, 'models/scaler.pkl')
print(f"   ✓ Scaler saved to models/scaler.pkl")

dump(X.columns.tolist(), 'models/feature_names.pkl')
print(f"   ✓ Feature names saved to models/feature_names.pkl")

print(f"\n{'='*60}")
print(f"✅ Model training complete! Ready to use.")
print(f"{'='*60}\n")
